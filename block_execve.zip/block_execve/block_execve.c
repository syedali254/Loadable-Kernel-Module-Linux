#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/syscalls.h>
#include <linux/version.h>
#include <linux/namei.h>
#include <linux/string.h>
#include <linux/kprobes.h>
#include <linux/cred.h>
#include <linux/fs.h>
#include <linux/slab.h>
#include <linux/fdtable.h>
#include <linux/uaccess.h>
#include <linux/ftrace.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Security Module");
MODULE_DESCRIPTION("A module to restrict execve based on program and UID using ftrace");
MODULE_VERSION("0.4");

/* Define our blocklist of programs */
static const char *blocklist[] = {
    "/usr/bin/nmap",
    "/usr/bin/netcat",
    "/usr/bin/nc",
    "/bin/nc",
    "/usr/bin/wireshark",
    "/usr/bin/tcpdump",
    "/usr/bin/vim",
    /* Add more programs as needed */
    NULL
};

/* Ftrace related data structures */
struct ftrace_hook {
    const char *name;
    void *function;
    void *original;
    unsigned long address;
    struct ftrace_ops ops;
};

/* Function prototype for the original __x64_sys_execve */
static asmlinkage long (*real_sys_execve)(const struct pt_regs *regs);

/* Helper function to check if a program is in the blocklist */
/* Helper function to check if a program is in the blocklist */
static int is_blocked(const char *path) {
    int i;
    for (i = 0; blocklist[i] != NULL; i++) {
        if (strcmp(path, blocklist[i]) == 0) {
            printk(KERN_INFO "execve_hook: Found blocked program %s\n", path);
            return 1;
        }
    }
    return 0;
}

/* Function to resolve and check the real path */
static int check_path(const char __user *pathname) {
    char *kernel_pathname;
    struct path path;
    char *tmp_path;
    char *filename;
    int blocked = 0;
    int ret = 0;
    
    /* Allocate memory for pathname */
    kernel_pathname = kmalloc(PATH_MAX, GFP_KERNEL);
    if (!kernel_pathname) {
        return 0;
    }
    
    /* Copy pathname from user space */
    ret = strncpy_from_user(kernel_pathname, pathname, PATH_MAX);
    if (ret < 0) {
        kfree(kernel_pathname);
        return 0;
    }
    
    /* Debug: Print the pathname we're checking */
    printk(KERN_DEBUG "execve_hook: Checking program: %s\n", kernel_pathname);
    
    /* Check the user-provided pathname against the blocklist */
    blocked = is_blocked(kernel_pathname);
    if (blocked) {
        kfree(kernel_pathname);
        return 1;
    }
    
    /* Resolve the full path */
    if (kern_path(kernel_pathname, LOOKUP_FOLLOW, &path) == 0) {
        tmp_path = kmalloc(PATH_MAX, GFP_KERNEL);
        if (tmp_path) {
            filename = d_path(&path, tmp_path, PATH_MAX);
            if (!IS_ERR(filename)) {
                /* Debug: Print the resolved path */
                printk(KERN_DEBUG "execve_hook: Resolved path: %s\n", filename);
                
                /* Check if the resolved path is blocked */
                blocked = is_blocked(filename);
            }
            kfree(tmp_path);
        }
        path_put(&path);
    }
    
    kfree(kernel_pathname);
    return blocked;
}

/* Our replacement for sys_execve */
static asmlinkage long fh_sys_execve(const struct pt_regs *regs) {
    char __user *pathname = (char __user *)regs->di;
    int blocked;
    
    /* Debug message to confirm hooks are working */
    printk(KERN_DEBUG "execve_hook: Intercepted execve call\n");
    
    /* Check if the program is blocked */
    blocked = check_path(pathname);
    if (blocked) {
        /* Check user ID - allow root, block others */
        if (current_uid().val != 0) {
            printk(KERN_INFO "execve_hook: Blocked execution by UID %d\n", current_uid().val);
            return -EACCES;
        }
        printk(KERN_INFO "execve_hook: Allowed execution by root (UID %d)\n", current_uid().val);
    }
    
    /* Call the original execve */
    return real_sys_execve(regs);
}

/* Ftrace callback handler - updated for ftrace_regs compatibility */
static void notrace fh_ftrace_thunk(unsigned long ip, unsigned long parent_ip,
                                    struct ftrace_ops *ops, struct ftrace_regs *fregs) {
    struct ftrace_hook *hook = container_of(ops, struct ftrace_hook, ops);
    struct pt_regs *regs = ftrace_get_regs(fregs);
    
    /* Skip if we're called by our own replacement function */
    if (!within_module(parent_ip, THIS_MODULE))
        regs->ip = (unsigned long)hook->function;
}

/* Use kprobe to get kallsyms_lookup_name */
typedef unsigned long (*kallsyms_lookup_name_t)(const char *name);
kallsyms_lookup_name_t kallsyms_lookup_name_func;

static struct kprobe kp = {
    .symbol_name = "kallsyms_lookup_name"
};

/* Get kallsyms_lookup_name function */
static kallsyms_lookup_name_t get_kallsyms_lookup_name(void) {
    /* Register the kprobe */
    if (register_kprobe(&kp) < 0) {
        printk(KERN_ERR "execve_hook: Could not register kprobe\n");
        return NULL;
    }
    
    /* Get the address of kallsyms_lookup_name */
    kallsyms_lookup_name_t func = (kallsyms_lookup_name_t) kp.addr;
    
    /* Unregister the kprobe */
    unregister_kprobe(&kp);
    return func;
}

/* Initialize a hook */
static int fh_install_hook(struct ftrace_hook *hook) {
    int err;
    kallsyms_lookup_name_t lookup_name;
    
    /* Get lookup_name function */
    lookup_name = get_kallsyms_lookup_name();
    if (!lookup_name) {
        printk(KERN_ERR "execve_hook: Failed to get kallsyms_lookup_name\n");
        return -ENOENT;
    }
    
    /* Look up the function address */
    hook->address = lookup_name(hook->name);
    if (!hook->address) {
        printk(KERN_DEBUG "execve_hook: Failed to lookup %s\n", hook->name);
        return -ENOENT;
    }
    
    /* Store original function pointer */
    *((unsigned long*)hook->original) = hook->address;
    
    /* Set up ftrace ops */
    hook->ops.func = fh_ftrace_thunk;
    hook->ops.flags = FTRACE_OPS_FL_SAVE_REGS | FTRACE_OPS_FL_IPMODIFY;
    
    /* Register and enable ftrace */
    err = ftrace_set_filter_ip(&hook->ops, hook->address, 0, 0);
    if (err) {
        printk(KERN_DEBUG "execve_hook: Failed to set ftrace filter\n");
        return err;
    }
    
    err = register_ftrace_function(&hook->ops);
    if (err) {
        printk(KERN_DEBUG "execve_hook: Failed to register ftrace function\n");
        ftrace_set_filter_ip(&hook->ops, hook->address, 1, 0);
        return err;
    }
    
    return 0;
}

/* Remove a hook */
static void fh_remove_hook(struct ftrace_hook *hook) {
    unregister_ftrace_function(&hook->ops);
    ftrace_set_filter_ip(&hook->ops, hook->address, 1, 0);
}

/* Hook definition */
static struct ftrace_hook hook_execve = {
    .name = "__x64_sys_execve",
    .function = fh_sys_execve,
    .original = &real_sys_execve,
};

static int __init execve_hook_init(void) {
    int err;
    
    /* Print blocklist for debugging */
    int i;
    for (i = 0; blocklist[i] != NULL; i++) {
        printk(KERN_INFO "execve_hook: Blocklisted program: %s\n", blocklist[i]);
    }
    
    /* Install the hook */
    err = fh_install_hook(&hook_execve);
    if (err) {
        printk(KERN_ERR "execve_hook: Failed to install hook: %d\n", err);
        return err;
    }
    
    printk(KERN_INFO "execve_hook: Module loaded successfully\n");
    return 0;
}

static void __exit execve_hook_exit(void) {
    /* Remove the hook */
    fh_remove_hook(&hook_execve);
    
    printk(KERN_INFO "execve_hook: Module unloaded successfully\n");
}

module_init(execve_hook_init);
module_exit(execve_hook_exit);
